using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Security.Cryptography;
using System.Text;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lbltime.Text ="Current Server Time :"+ DateTime.Now.ToString(@"yyyy\:MM\:dd-HH\:mm\:ss");
        lblmytime.Text = "Server Time after  :"+DateTime.Now.AddHours(5).AddMinutes(30).ToString(@"yyyy\:MM\:dd-HH\:mm\:ss");
    }
    protected void btnSend_Click(object sender, EventArgs e)
    {
        string formCode = "<form id=\"{0}\" name=\"{0}\" method=\"post\" action=\"{1}\">" +
                          "<input type=\"hidden\" name=\"txntype\" value=\"sale\">" +
                          "<input type=\"hidden\" name=\"timezone\" value=\"IST\"/>" +
                          "<input type=\"hidden\" name=\"txndatetime\" value=\"{2}\"/>" +
                          "<input type=\"hidden\" name=\"hash\" value=\"{3}\"/>" +
                          "<input type=\"hidden\" name=\"storename\" value=\"{4}\" />" +
                          "<input type=\"hidden\" name=\"mode\" value=\"payonly\"/>" +
                          "<input type=\"hidden\" name=\"currency\" value=\"{5}\" />" +
                          "<input type=\"hidden\" name=\"chargetotal\" value=\"{6}\"/>" +
						  "<input type=\"hidden\" name=\"language\" value=\"en_EN\"/>" +
                          "<input type=\"hidden\" name=\"responseFailURL\" value=\"http://10.24.94.240:8055/IPGConnectNew.NET/response_fail.aspx\"/>" + //need to change as per merchant ip/url
						  "<input type=\"hidden\" name=\"responseSuccessURL\" value=\"http://10.24.94.240:8055/IPGConnectNew.NET/response_success.aspx\"/>" + //need to change as per merchant ip/url
                          "</form>";

        string formScript = "<script language=\"javascript\" type=\"text/javascript\">" +
                            "document.getElementById('{0}').submit();" +
                            "</script>";

        string formName = "form1";
   	
        string formAction ="https://test.ipg-online.com/connect/gateway/processing";
        string storename = this.storename.Text;
        string txndatetime = DateTime.Now.ToString(@"yyyy\:MM\:dd-HH\:mm\:ss");
        string chargetotal = this.chargetotal.Text;
        string sharedsecret = this.sharedsecret.Text;
        string currency = this.currency.SelectedValue.ToString();
		string data =  storename + txndatetime + chargetotal + currency + sharedsecret;
        string hash = calculateHashFromString(new StringBuilder(data),"SHA1");
        ltrForm.Text = string.Format(formCode, formName, formAction, txndatetime, hash, storename, currency, chargetotal);
        ltrScript.Text = string.Format(formScript, formName);
    }

	public string getSHA1(string stringa)
    {
        return BitConverter.ToString(SHA1Managed.Create().ComputeHash(Encoding.ASCII.GetBytes(stringa)));
    }

	public static String calculateHashFromString(StringBuilder stringValue, String hashAlgorithmName)
    {
       
        HashAlgorithm hashAlgorithm = HashAlgorithm.Create(hashAlgorithmName.Length == 0 ? "SHA1" : hashAlgorithmName);

        StringBuilder sb = new StringBuilder();

        byte[] stringValueBytes = Encoding.ASCII.GetBytes(stringValue.ToString());

        int stringValueBytesLength = stringValueBytes.Length;

        for (int i = 0; i < stringValueBytesLength; i++)
        {
            sb.Append(forDigit((stringValueBytes[i] & 240) >> 4, 16));
            sb.Append(forDigit((stringValueBytes[i] & 15), 16));
        }

        stringValueBytes = Encoding.ASCII.GetBytes((new StringBuilder(sb.ToString()).ToString()));

        hashAlgorithm.TransformFinalBlock(stringValueBytes, 0, stringValueBytes.Length);
        byte[] hash = hashAlgorithm.Hash;
        int hashLength = hash.Length;

        return BitConverter.ToString(hash).Replace("-", "").ToLower();
    }

   
    private static char forDigit(int digit, int radix)
    {
        int MIN_RADIX = 2, MAX_RADIX = 36;
        if ((digit >= radix) || (digit < 0))
        {
            return '\0';
        }
        if ((radix < MIN_RADIX) || (radix > MAX_RADIX))
        {
            return '\0';
        }
        if (digit < 10)
        {
            return (char)('0' + digit);
        }
        return (char)('a' - 10 + digit);
    }
	
}
