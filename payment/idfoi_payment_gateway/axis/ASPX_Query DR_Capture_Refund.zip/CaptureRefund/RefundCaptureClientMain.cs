﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
namespace ASPParty
{
    class RefundCaptureClientMain
    {
       

        static void Main(string[] args)
         {
           RefundCaptureClient objRefundCaptureClient=new RefundCaptureClient();
           Dictionary<string,string> initData=objRefundCaptureClient.initializeData();
           objRefundCaptureClient.capture(initData);
           
        }
    }
}
