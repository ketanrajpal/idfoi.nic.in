﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
namespace ASPParty
{
    class StatusMain
    {
       

        static void Main(string[] args)
         {
           StatusClient objStatusClient = new StatusClient();
           Dictionary<string, string> initData = objStatusClient.initializeData();
           objStatusClient.Status(initData);
           
        }
    }
}
