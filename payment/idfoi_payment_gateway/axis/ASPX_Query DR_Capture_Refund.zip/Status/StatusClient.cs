﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ASPParty
{
    class StatusClient
    {

        // _________________________________________________________________________

        public string getResponseDescription(string vResponseCode)
        {
            /* 
             <summary>Maps the vpc_TxnResponseCode to a relevant description</summary>
             <param name="vResponseCode">The vpc_TxnResponseCode returned by the transaction.</param>
             <returns>The corresponding description for the vpc_TxnResponseCode.</returns>
             */
            string result = "Unknown";

            if (vResponseCode.Length > 0)
            {
                switch (vResponseCode)
                {
                    case "0": result = "Transaction Successful"; break;
                    case "1": result = "Transaction Declined"; break;
                    case "2": result = "Bank Declined Transaction"; break;
                    case "3": result = "No Reply from Bank"; break;
                    case "4": result = "Expired Card"; break;
                    case "5": result = "Insufficient Funds"; break;
                    case "6": result = "Error Communicating with Bank"; break;
                    case "7": result = "Payment Server detected an error"; break;
                    case "8": result = "Transaction Type Not Supported"; break;
                    case "9": result = "Bank declined transaction (Do not contact Bank)"; break;
                    case "A": result = "Transaction Aborted"; break;
                    case "B": result = "Transaction Declined - Contact the Bank"; break;
                    case "C": result = "Transaction Cancelled"; break;
                    case "D": result = "Deferred transaction has been received and is awaiting processing"; break;
                    case "F": result = "3-D Secure Authentication failed"; break;
                    case "I": result = "Card Security Code verification failed"; break;
                    case "L": result = "Shopping Transaction Locked (Please try the transaction again later)"; break;
                    case "N": result = "Cardholder is not enrolled in Authentication scheme"; break;
                    case "P": result = "Transaction has been received by the Payment Adaptor and is being processed"; break;
                    case "R": result = "Transaction was not processed - Reached limit of retry attempts allowed"; break;
                    case "S": result = "Duplicate SessionID"; break;
                    case "T": result = "Address Verification Failed"; break;
                    case "U": result = "Card Security Code Failed"; break;
                    case "V": result = "Address Verification and Card Security Code Failed"; break;
                    default: result = "Unable to be determined"; break;
                }
            }
            return result;
        }


        // _________________________________________________________________________

        public string getAVSDescription(string vAVSResultCode)
        {
            /*
             <summary>Maps the vpc_AVSResultCode to a relevant description</summary>
             <param name="vAVSResultCode">The vpc_AVSResultCode returned by the transaction.</param>
             <returns>The corresponding description for the vpc_AVSResultCode.</returns>
             */
            string result = "Unknown";

            if (vAVSResultCode.Length > 0)
            {
                if (vAVSResultCode.Equals("Unsupported"))
                {
                    result = "AVS not supported or there was no AVS data provided";
                }
                else
                {
                    switch (vAVSResultCode)
                    {
                        case "X": result = "Exact match - address and 9 digit ZIP/postal code"; break;
                        case "Y": result = "Exact match - address and 5 digit ZIP/postal code"; break;
                        case "S": result = "Service not supported or address not verified (international transaction)"; break;
                        case "G": result = "Issuer does not participate in AVS (international transaction)"; break;
                        case "A": result = "Address match only"; break;
                        case "W": result = "9 digit ZIP/postal code matched, Address not Matched"; break;
                        case "Z": result = "5 digit ZIP/postal code matched, Address not Matched"; break;
                        case "R": result = "Issuer system is unavailable"; break;
                        case "U": result = "Address unavailable or not verified"; break;
                        case "E": result = "Address and ZIP/postal code not provided"; break;
                        case "N": result = "Address and ZIP/postal code not matched"; break;
                        case "0": result = "AVS not requested"; break;
                        default: result = "Unable to be determined"; break;
                    }
                }
            }
            return result;
        }

        //______________________________________________________________________________

        public string getCSCDescription(string vCSCResultCode)
        {
            /*
             <summary>Maps the vpc_CSCResultCode to a relevant description</summary>
             <param name="vCSCResultCode">The vpc_CSCResultCode returned by the transaction.</param>
             <returns>The corresponding description for the vpc_CSCResultCode.</returns>
             */
            string result = "Unknown";
            if (vCSCResultCode.Length > 0)
            {
                if (vCSCResultCode.Equals("Unsupported"))
                {
                    result = "CSC not supported or there was no CSC data provided";
                }
                else
                {

                    switch (vCSCResultCode)
                    {
                        case "M": result = "Exact code match"; break;
                        case "S": result = "Merchant has indicated that CSC is not present on the card (MOTO situation)"; break;
                        case "P": result = "Code not processed"; break;
                        case "U": result = "Card issuer is not registered and/or certified"; break;
                        case "N": result = "Code invalid or not matched"; break;
                        default: result = "Unable to be determined"; break;
                    }
                }
            }
            return result;
        }

        //______________________________________________________________________________

        public System.Collections.Hashtable splitResponse(string rawData)
        {
            /*
             <summary>Parses a HTTP POST to extract the parmaters from the POST data</summary>
             <param name="rawData">The raw data from the body of a HTTP POST.</param>
             <returns>A Hashtable containing the parameters returned in the body of a HTTP POST.</returns>

             <remarks>
             <para>
             This function parses the content of the VPC response to extract the 
             individual parameter names and values. These names and values are then 
             returned as a Hashtable.
             </para>

             <para>
             The content returned by the VPC is a HTTP POST, so the content will 
             be in the format <c>parameter1=value&parameter2=value&parameter3=value</c>, 
             i.e. key/value pairs separated by ampersands "&".
             </para>
             </remarks>
             */

            System.Collections.Hashtable responseData = new System.Collections.Hashtable();
            try
            {
                // Check if there was a response containing parameters
                if (rawData.IndexOf("=") > 0)
                {
                    // Extract the key/value pairs for each parameter
                    foreach (string pair in rawData.Split('&'))
                    {
                        int equalsIndex = pair.IndexOf("=");
                        if (equalsIndex > 1 && pair.Length > equalsIndex)
                        {
                            string paramKey = System.Web.HttpUtility.UrlDecode(pair.Substring(0, equalsIndex));
                            string paramValue = System.Web.HttpUtility.UrlDecode(pair.Substring(equalsIndex + 1));
                            responseData.Add(paramKey, paramValue);
                        }
                    }
                }
                else
                {
                    // There were no parameters so create an error
                    responseData.Add("vpc_Message", "The data contained in the response was not a valid receipt. \n The data was:" + rawData + "\n");
                }
                return responseData;
            }
            catch (Exception ex)
            {
                // There was an exception so create an error
                responseData.Add("vpc_Message", "\n The was an exception parsing the response data. \n The data was: " + rawData + "\n\n Exception: " + ex.ToString() + "\n");
                return responseData;
            }
        }


        public Dictionary<string, string> initializeData()
        {
            Dictionary<string, string> dct = new Dictionary<string, string>();

            try
            {
                dct.Add("vpcURL", @"https://geniusepay.in/VAS/QueryDR");
                dct.Add("vpc_Command", "QueryDr");
                dct.Add("vpc_AccessCode", "");
                dct.Add("vpc_MerchTxnRef", "");
                dct.Add("vpc_Merchant", "");
                dct.Add("SecureHash", CreateSHA256Signature(getRawHashData(dct)));
            }
            catch (Exception ex)
            {

            }

            return dct;
        }

        public void Status(Dictionary<string, string> initData)
        {
            /*

           // Initialisation
           // ==============

           /*
            *******************************************
            * Define Variables
            *******************************************
            */

            string debugData = "";

            string postData = "";

            // define message string for errors
            string message = "";

            // error exists flag
            bool errorExists = false;

            // transaction response code
            string txnResponseCode = "";

            try
            {
                /*
                 *************************
                 * START OF MAIN PROGRAM *
                 *************************
                 */



                // Collect debug information
# if DEBUG
                debugData += "Data from Order Page \n ";
# endif

                // Loop through all the data in the Page.Request.Form
                ///foreach (KeyValuePair<string, string> item in initData)
                ///{

                // Collect debug information
                ///# if DEBUG
                ///debugData += item.Key.Trim().ToString() + "=" + item.Value.Trim().ToString() + "\n";
                /// # endif

                /* 
        * Only include those fields required for a transaction
        * Extract the Form POST data and ignore the 
        * URL, the Submit button and any empty form fields, as we do not 
        * want to send these fields to the URL. 
        */

                // Remove the trailing ampersand on the POST data string
                ///postData = postData.Substring(0, postData.Length - 1);

                postData = initData["QueryString"] + "&" + "SecureHash=" + initData["SecureHash"];


                string vpcURL = "Unknown";
                if (initData.ContainsKey("vpcURL"))
                    vpcURL = initData["vpcURL"];

                // Collect debug information
# if DEBUG
                debugData += " \n Destination of POST data operation: " + vpcURL + " \n Post Data String: " + postData + " \n ";
# endif

                //System.Net.ServicePointManager.ServerCertificateValidationCallback = (object se, System.Security.Cryptography.X509Certificates.X509Certificate cert, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslerror) => true;


                // Perform the VPC request (i.e. HTTPS POST) and obtain the VPC response
                System.Net.WebClient webClient = new System.Net.WebClient();
                webClient.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
                byte[] response = webClient.UploadData(vpcURL, "POST", Encoding.ASCII.GetBytes(postData));

                // Convert the response to a string from a byte array and parse it to extract
                // the data using the splitResponse function. Store results in a hashtable.
                string responseData = System.Text.Encoding.ASCII.GetString(response, 0, response.Length);
                System.Collections.Hashtable responseParameters = splitResponse(responseData);

                // Collect debug information
# if DEBUG
                debugData += "\n Response of POST data operation: " + responseData + "\n";
# endif

                // Get the standard receipt data from the parsed response

                //-----------------------------------

                string Label_vpc_AuthorizeId = responseParameters.ContainsKey("vpc_AuthorizeId") ? responseParameters["vpc_AuthorizeId"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_AuthorizeId=" + Label_vpc_AuthorizeId);

                string Label_vpc_BatchNo = responseParameters.ContainsKey("vpc_BatchNo") ? responseParameters["vpc_BatchNo"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_BatchNo=" + Label_vpc_BatchNo);

                string Label_vpc_Card = responseParameters.ContainsKey("vpc_Card") ? responseParameters["vpc_Card"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_Card=" + Label_vpc_Card);

                string Label_vpc_Version = responseParameters.ContainsKey("vpc_Version") ? responseParameters["vpc_Version"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_Version=" + Label_vpc_Version);

                string Label_vpc_Merchant = responseParameters.ContainsKey("vpc_Merchant") ? responseParameters["vpc_Merchant"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_Merchant=" + Label_vpc_Merchant);

                string Label_vpc_Amount = responseParameters.ContainsKey("vpc_Amount") ? responseParameters["vpc_Amount"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_Amount=" + Label_vpc_Amount);

                string Label_vpc_3DSstatus = responseParameters.ContainsKey("vpc_3DSstatus") ? responseParameters["vpc_3DSstatus"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_3DSstatus=" + Label_vpc_3DSstatus);

                string Label_vpc_MerchTxnRef = responseParameters.ContainsKey("vpc_MerchTxnRef") ? responseParameters["vpc_MerchTxnRef"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_MerchTxnRef=" + Label_vpc_MerchTxnRef);

                string Label_vpc_CSCResultCode = responseParameters.ContainsKey("vpc_CSCResultCode") ? responseParameters["vpc_CSCResultCode"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_CSCResultCode=" + Label_vpc_CSCResultCode);

                string Label_vpc_VerToken = responseParameters.ContainsKey("vpc_VerToken") ? responseParameters["vpc_VerToken"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_VerToken=" + Label_vpc_VerToken);

                string Label_SecureHash = responseParameters.ContainsKey("SecureHash") ? responseParameters["SecureHash"].ToString() : "Unknown";
                Console.WriteLine("Label_SecureHash=" + Label_SecureHash);

                string Label_vpc_OrderInfo = responseParameters.ContainsKey("vpc_OrderInfo") ? responseParameters["vpc_OrderInfo"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_OrderInfo=" + Label_vpc_OrderInfo);


                string Label_vpc_Command = responseParameters.ContainsKey("vpc_Command") ? responseParameters["vpc_Command"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_Command=" + Label_vpc_Command);


                string Label_vpc_3DSenrolled = responseParameters.ContainsKey("vpc_3DSenrolled") ? responseParameters["vpc_3DSenrolled"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_3DSenrolled=" + Label_vpc_3DSenrolled);


                string Label_vpc_CSCRequestCode = responseParameters.ContainsKey("vpc_CSCRequestCode") ? responseParameters["vpc_CSCRequestCode"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_CSCRequestCode=" + Label_vpc_CSCRequestCode);

                string Label_vpc_AcqResponseCode = responseParameters.ContainsKey("vpc_AcqResponseCode") ? responseParameters["vpc_AcqResponseCode"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_AcqResponseCode=" + Label_vpc_AcqResponseCode);


                string Label_vpc_VerType = responseParameters.ContainsKey("vpc_VerType") ? responseParameters["vpc_VerType"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_VerType=" + Label_vpc_VerType);


                string Label_vpc_TransactionNo = responseParameters.ContainsKey("vpc_TransactionNo") ? responseParameters["vpc_TransactionNo"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_TransactionNo=" + Label_vpc_TransactionNo);


                string Label_vpc_VerSecurityLevel = responseParameters.ContainsKey("vpc_VerSecurityLevel") ? responseParameters["vpc_VerSecurityLevel"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_VerSecurityLevel=" + Label_vpc_VerSecurityLevel);


                string Label_vpc_ReceiptNo = responseParameters.ContainsKey("vpc_ReceiptNo") ? responseParameters["vpc_ReceiptNo"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_ReceiptNo=" + Label_vpc_ReceiptNo);


                string Label_message = responseParameters.ContainsKey("message") ? responseParameters["message"].ToString() : "Unknown";
                Console.WriteLine("Label_message=" + Label_message);


                string Label_vpc_3DSXID = responseParameters.ContainsKey("vpc_3DSXID") ? responseParameters["vpc_3DSXID"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_3DSXID=" + Label_vpc_3DSXID);


                string Label_vpc_3DSECI = responseParameters.ContainsKey("vpc_3DSECI") ? responseParameters["vpc_3DSECI"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_3DSECI=" + Label_vpc_3DSECI);


                string Label_vpc_Locale = responseParameters.ContainsKey("vpc_Locale") ? responseParameters["vpc_Locale"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_Locale=" + Label_vpc_Locale);


                string Label_vpc_AcqCSCRespCode = responseParameters.ContainsKey("vpc_AcqCSCRespCode") ? responseParameters["vpc_AcqCSCRespCode"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_AcqCSCRespCode=" + Label_vpc_AcqCSCRespCode);


                string Label_vpc_VerStatus = responseParameters.ContainsKey("vpc_VerStatus") ? responseParameters["vpc_VerStatus"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_VerStatus=" + Label_vpc_VerStatus);


                string Label_vpc_TxnResponseCode = responseParameters.ContainsKey("vpc_TxnResponseCode") ? responseParameters["vpc_TxnResponseCode"].ToString() : "Unknown";
                Console.WriteLine("Label_vpc_TxnResponseCode=" + Label_vpc_TxnResponseCode);



                //-----------------------------------



                if (message.Length == 0)
                {
                    message = responseParameters.ContainsKey("vpc_Message") ? responseParameters["vpc_Message"].ToString() : "Unknown";
                }

            }
            catch (Exception ex)
            {
                message = "(51) Exception encountered. " + ex.Message;
                string Label_StackTrace = "";
                if (ex.StackTrace.Length > 0)
                {
                    Label_StackTrace = ex.ToString();
                    Console.WriteLine(Label_StackTrace);
                }
                errorExists = true;
            }




            // Output debug data to the screen
            string Label_Debug = "";
/*# if DEBUG
            debugData += " \n End of debug information \n";
            Label_Debug = debugData;
            Console.WriteLine("Label_Debug" + Label_Debug);
# endif*/

            //LogMessage("postData - \n" + postData + "\n Debug Data - \n" + debugData,"f:\\log.txt");
            Console.Read();
            /*
            
    **********************
    * END OF MAIN PROGRAM
    **********************
    *
    * FINISH TRANSACTION - Output the VPC Response Data
    * =====================================================
    * For the purposes of demonstration, we simply display the Result fields
    * on a web page.
    */
        }

        public void LogMessage(string Message, string FileName)
        {
            try
            {
                using (TextWriter tw = new StreamWriter(FileName, true))
                {
                    tw.WriteLine(DateTime.Now.ToString() + " - \n " + Message);
                }
            }
            catch (Exception ex)  //Writing to log has failed, send message to trace in case anyone is listening.
            {
                System.Diagnostics.Trace.Write(ex.ToString());
            }
        }

        private string CreateSHA256Signature(string RawData)
        {
            /*
             <summary>Creates a SHA256 Signature</summary>
             <param name="RawData">The string used to create the SHA256 signautre.</param>
             <returns>A string containing the SHA256 signature.</returns>
             */

            System.Security.Cryptography.SHA256 hasher = System.Security.Cryptography.SHA256Managed.Create();
            byte[] HashValue = hasher.ComputeHash(Encoding.ASCII.GetBytes(RawData));

            string strHex = "";
            foreach (byte b in HashValue)
            {
                strHex += b.ToString("x2");
            }
            return strHex.ToUpper();
        }

        //______________________________________________________________________________

        private string getRawHashData(Dictionary<string, string> inputData)
        {
            string SECURE_SECRET = "";
            string queryString = "";
            string debugData = "";
            try
            {
                // NOTE: We use our own overloaded IComparer interface to ensure we do 
                // an Ordinal sort of the data.
                System.Collections.SortedList transactionData = new System.Collections.SortedList(new EMAStringComparer());


                foreach (KeyValuePair<string, string> item in inputData)
                {

                    // Collect debug information
# if DEBUG
                    debugData += item.Key.Trim().ToString() + "=" + item.Value.Trim().ToString() + "\n";
# endif

                    /* 
            * Only include those fields required for a transaction
            */
                    if ((item.Key.Trim().ToString() != "") && (item.Key.Trim().ToString() != "vpcURL"))
                    {

                        transactionData.Add(item.Key.Trim().ToString(), item.Value.Trim().ToString());
                    }
                }

                string rawHashData = SECURE_SECRET;
                //string seperator = "?";
                string seperator = "";

                // Loop through all the data in the SortedList transaction data
                foreach (System.Collections.DictionaryEntry item in transactionData)
                {

                    // Collect debug information
# if DEBUG
                    debugData += item.Key.ToString() + "=" + item.Value.ToString() + "\n";
# endif

                    // build the query string, URL Encoding all keys and their values
                    queryString += seperator + System.Web.HttpUtility.UrlEncode(item.Key.ToString()) + "=" + System.Web.HttpUtility.UrlEncode(item.Value.ToString());
                    seperator = "&";

                    // Collect the data required for the SHA256 sugnature if required
                    if (SECURE_SECRET.Length > 0)
                    {
                        rawHashData += item.Value.ToString();
                    }
                }
                inputData.Add("QueryString", queryString);
                return rawHashData;

            }
            catch (Exception ex)
            {
                return "Error At getRawHashData(): =" + ex.Message.ToString();
            }


        }

        private class EMAStringComparer : System.Collections.IComparer
        {
            /*
             <summary>Customised Compare Class</summary>
             <remarks>
             <para>
             The  URL need to use an Ordinal comparison to Sort on 
             the field names to create the SHA256 Signature for validation of the message. 
             This class provides a Compare method that is used to allow the sorted list 
             to be ordered using an Ordinal comparison.
             </para>
             </remarks>
             */

            public int Compare(Object a, Object b)
            {
                /*
                 <summary>Compare method using Ordinal comparison</summary>
                 <param name="a">The first string in the comparison.</param>
                 <param name="b">The second string in the comparison.</param>
                 <returns>An int containing the result of the comparison.</returns>
                 */

                // Return if we are comparing the same object or one of the 
                // objects is null, since we don't need to go any further.
                if (a == b) return 0;
                if (a == null) return -1;
                if (b == null) return 1;

                // Ensure we have string to compare
                string sa = a as string;
                string sb = b as string;

                // Get the CompareInfo object to use for comparing
                System.Globalization.CompareInfo myComparer = System.Globalization.CompareInfo.GetCompareInfo("en-US");
                if (sa != null && sb != null)
                {
                    // Compare using an Ordinal Comparison.
                    return myComparer.Compare(sa, sb, System.Globalization.CompareOptions.Ordinal);
                }
                throw new ArgumentException("a and b should be strings.");
            }
        }

    }
}
